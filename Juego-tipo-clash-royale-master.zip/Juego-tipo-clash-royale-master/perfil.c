#include <stdio.h>
#include <stdbool.h>
#include "perfil.h"

const int ARIES = 1;
const int TAURO = 2;
const int GEMINIS = 3;
const int CANCER = 4;
const int LEO = 5;
const int VIRGO = 6;
const int LIBRA = 7;
const int ESCORPIO = 8;
const int SAGITARIO = 9;
const int CAPRICORNIO = 10;
const int ACUARIO = 11;
const int PISCIS = 12;

const char ACCION = 'A';
const char TERROR = 'T';
const char COMEDIA = 'C';
const char DRAMA = 'D';

const int MALDADES_MIN = 0;
const int MALDADES_MAX = 99;
const int MALDADES_OFENSIVO = 50;

const int MASCOTAS_MIN = 0;
const int MASCOTAS_MAX = 5;

const int INTENSIDAD_DEFENSIVA_MIN1 = 0;
const int INTENSIDAD_DEFENSIVA_MIN2 = 10;
const int INTENSIDAD_DEFENSIVA_MIN3 = 20;
const int INTENSIDAD_DEFENSIVA_MIN4 = 30;
const int INTENSIDAD_DEFENSIVA_MIN5 = 40;

const int INTENSIDAD_OFENSIVA_MIN1 = 50;
const int INTENSIDAD_OFENSIVA_MIN2 = 60;
const int INTENSIDAD_OFENSIVA_MIN3 = 70;
const int INTENSIDAD_OFENSIVA_MIN4 = 80;
const int INTENSIDAD_OFENSIVA_MIN5 = 90;


/*	
	Pre-condiciones: ingresar solamente caracteres.
	Post-condiciones: devuelve si lo que ingresaste es un tipo de pelicula permitida o no.
*/
bool pelicula_permitida(char genero_pelicula){
	if(genero_pelicula==ACCION||genero_pelicula==TERROR||genero_pelicula==COMEDIA||genero_pelicula==DRAMA)
		return true;
	else
		return false;
}

/*	
	Pre-condiciones: ingresar solamente caracteres.
	Post-condiciones: si ingresaste algo fuera del rango permitido, te vuelve a pedir que ingreses un caracter hasta que se valide el rango
*/
void validar_pelicula(char *genero_pelicula){
	int pelicula_sin_validar;

	pelicula_sin_validar = pelicula_permitida(*genero_pelicula);

	while(!pelicula_sin_validar)
	{
		//printf("El tipo de película ingresada es inválida/no se encuentra dentro del rango, por favor ingresela nuevamente\n");
		scanf(" %c", genero_pelicula);

		pelicula_sin_validar = pelicula_permitida(*genero_pelicula);
	}
	
}

/*	
	Pre-condiciones: ingresar solamente caracteres.
	Post-condiciones: devuelve si lo que ingresaste es un tipo de variable permitida o no.
*/
bool variable_permitida(int variable_sin_validar, int rango_min, int rango_max){
	return((variable_sin_validar <= rango_max) && (variable_sin_validar >= rango_min));
}

/*	
	Pre-condiciones: ingresar solamente caracteres.
	Post-condiciones: si ingresaste algo fuera del rango permitido, te vuelve a pedir que ingreses un caracter hasta que se valide el rango.
*/
void validar_variable(int *variable_sin_validar, int rango_min, int rango_max){
	int variable_valida;
	variable_valida = variable_permitida(*variable_sin_validar, rango_min, rango_max);

	while(!variable_valida){
		//printf("El dato ingresado es inválido/no se encuentra dentro del rango permitido, por favor ingreselo nuevamente\n");
		scanf("%i", variable_sin_validar);

		variable_valida = variable_permitida(*variable_sin_validar, rango_min, rango_max);
	}
	
}

/*	
	Pre-condiciones: sin pre-condiciones.
	Post-condiciones: almacena los datos que ingreso el usuario en cada variable.
*/
void pedir_datos(char *genero_pelicula, int *cant_maldades, int *cant_mascotas, int *signo_zodiaco){
	//printf("Ingrese el numero de su signo del zodiaco, con su respectivo número (por ejemplo, aries es 1): \n");
	scanf("%i", signo_zodiaco);

	validar_variable(signo_zodiaco, ARIES, PISCIS);
	//printf("Ingrese su genero favorito de pelicula, las permitidas son A (acción), C (comedia), D (drama) o T (terror): \n");
	scanf(" %c", genero_pelicula);

	validar_pelicula(genero_pelicula);

	//printf("Ingrese cuantas maldades hizo en el ultimo mes (un rango entre 0 y 99): \n");
	scanf("%i", cant_maldades);

	validar_variable(cant_maldades, MALDADES_MIN, MALDADES_MAX);

	//printf("Ingrese cuantas mascotas tiene (de 0 a 5, si tiene mas ingrese 5): \n");
	scanf("%i", cant_mascotas);

	validar_variable(cant_mascotas, MASCOTAS_MIN, MASCOTAS_MAX);

}

/*	
	Pre-condiciones: ingresar variables inicializadas.
	Post-condiciones: devuelve un numero por cada bando.
*/
int numero_bando(int signo_zodiaco, int cant_maldades, int cant_mascotas, char genero_pelicula){
	if( (signo_zodiaco == ARIES || signo_zodiaco == LEO || signo_zodiaco == SAGITARIO || signo_zodiaco == GEMINIS || signo_zodiaco == LIBRA || signo_zodiaco == ACUARIO) && ( genero_pelicula == 'C' || genero_pelicula == 'T') && ( cant_maldades >= MALDADES_OFENSIVO ))
		return 1;
	else if ( (signo_zodiaco == TAURO || signo_zodiaco == VIRGO || signo_zodiaco == CAPRICORNIO || signo_zodiaco == CANCER || signo_zodiaco == ESCORPIO || signo_zodiaco == PISCIS) && ( genero_pelicula == 'A' || genero_pelicula == 'D') && ( cant_maldades < MALDADES_OFENSIVO ) )
		return 2;
	else
		return 0;
}

/*	
	Pre-condiciones: ingresar variables inicializadas.
	Post-condiciones: valida que los datos ingresados por el usuario puedan agruparse en un bando o el otro, sino vuelve a pedir los datos hasta que ocurra.
*/
void determinar_bando(int *bando, char *genero_pelicula, int *cant_maldades, int *cant_mascotas, int *signo_zodiaco){

	while(!*bando){
		//printf("No pudimos determinar su bando, le vamos a pedir que cambie algunos datos\n");
		pedir_datos(genero_pelicula, cant_maldades, cant_mascotas, signo_zodiaco);

		*bando = numero_bando(*signo_zodiaco, *cant_maldades, *cant_mascotas, *genero_pelicula);
	}
}

/*	
	Pre-condiciones: ingresar numeros enteros.
	Post-condiciones: devuelve cuanto vale la intensidad, con los datos ingresados por el usuario.
*/
int calculo_intensidad(int cant_maldades, int cant_mascotas, int rango1, int rango2, int rango3, int rango4, int rango5){
	int variable_intensidad = 0;
	if((cant_maldades >= rango1) && (cant_maldades < rango2))
		variable_intensidad = 1;
	else if((cant_maldades >= rango2) && (cant_maldades < rango3))
		variable_intensidad = 2;
	else if((cant_maldades >= rango3) && (cant_maldades < rango4))
		variable_intensidad = 3;
	else if((cant_maldades >= rango4) && (cant_maldades < rango5))
		variable_intensidad = 4;
	else
		variable_intensidad = 5;

	return variable_intensidad + cant_mascotas;
}

/*	
	Pre-condiciones: ingresar numeros enteros.
	Post-condiciones: le asigna un rango a cada bando y devuelve el calculo de su intensidad, por medio de otra funcion.
*/
int intensidad_total(int bando, int cant_maldades, int cant_mascotas){
	int calculo = 0;
	if(bando == 1)
		calculo = calculo_intensidad(cant_maldades, cant_mascotas, INTENSIDAD_OFENSIVA_MIN1, INTENSIDAD_OFENSIVA_MIN2, INTENSIDAD_OFENSIVA_MIN3, INTENSIDAD_OFENSIVA_MIN4, INTENSIDAD_OFENSIVA_MIN5);
	else
		calculo = calculo_intensidad(cant_maldades, cant_mascotas, INTENSIDAD_DEFENSIVA_MIN1, INTENSIDAD_DEFENSIVA_MIN2, INTENSIDAD_DEFENSIVA_MIN3, INTENSIDAD_DEFENSIVA_MIN4, INTENSIDAD_DEFENSIVA_MIN5);

	return calculo;
}

void perfil(char *tipo, int *intensidad){
	char genero_pelicula;
	int cant_maldades;
	int cant_mascotas;
	int signo_zodiaco;
	int bando;

	pedir_datos(&genero_pelicula, &cant_maldades, &cant_mascotas, &signo_zodiaco);

	bando = numero_bando(signo_zodiaco, cant_maldades, cant_mascotas, genero_pelicula);

	determinar_bando(&bando, &genero_pelicula, &cant_maldades, &cant_mascotas, &signo_zodiaco);

	*intensidad = intensidad_total(bando, cant_maldades, cant_mascotas);

	if(bando == 1){
		*tipo = 'I';
	}else{
		*tipo = 'R';
	}

}