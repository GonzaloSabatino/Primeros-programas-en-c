#ifndef __BATALLA_H__
#define __BATALLA_H__

#include <stdbool.h>

#define MAX_TERRENO_FIL 10
#define MAX_TERRENO_COL 10
#define MAX_PERSONAJES 300

typedef struct personaje {
	char codigo;
	int vida;
	int ataque;
	int fila;
	int columna;
	bool tiene_companiero_cerca;
} personaje_t;

typedef struct juego {
	char terreno[MAX_TERRENO_FIL][MAX_TERRENO_COL];
	int cantidad_turnos;
	personaje_t rohan[MAX_PERSONAJES];
	int cantidad_rohan;
	int llegadas_rohan;
	int plus_rohan;
	int energia_rohan;
	bool usuario_1_es_rohan;
	personaje_t isengard[MAX_PERSONAJES];
	int cantidad_isengard;
	int llegadas_isengard;
	int plus_isengard;
	int energia_isengard;
} juego_t;

/*
 *	Pre-condiciones: Recibe un carácter correctamente cargado.
 *	Post-condiciones: Permitirá únicamente que el jugador 1 disponga de su turno para realizar su jugada (atacar, mover, posicionar, eliminar rivales, sumar llegadas), pasará al turno de la máquina, luego sumará uno a la energía de cada bando.
 */
void turno_1_jugador(juego_t* juego);

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Permitirá que cada jugador disponga de un turno para realizar cada jugada (atacar, mover, posicionar, eliminar rivales, sumar llegadas), luego sumará uno a la energía de cada bando.
 */
void turno_2_jugadores(juego_t* juego);

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Devolverá la letra correspondiente al bando del usuario 1.
 */
char determinar_bando_usuario_1(juego_t* juego);

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Preguntará al usuario 1 si quiere jugar contra otro usuario o si desea hacerlo contra la máquina.
 */
void decidir_cuantos_jugadores(int *cant_jugadores);

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Devolverá true en caso de que no haya ningún ganador, false en caso de que un jugador haya llegado con 5 o más personajes a la meta.
 */
bool sigue_juego(juego_t juego);

/*
 * Pre-condiciones: No tiene.
 * Post-condiciones: Inicializará todos los valores del juego, dejándolo en un estado inicial válido.
 */
void inicializar_juego(juego_t* juego);

/*
 * Pre-condiciones: Recibirá un personaje, con todos sus campos correctamente cargados.
 * Post-condiciones: Dará de alta en el juego al personaje cargado, sumándolo al vector correspondiente,
 * posicionándolo también en la matriz.
 */
void posicionar_personaje(juego_t* juego, personaje_t personaje);

/*
 * Pre-condiciones: Recibe un bando en la posición posicion_personaje correctamente cargada, al igual que el bando como un caracter.
 * Post-condiciones: Realizará la jugada del personaje del bando recibido.
 * Se moverá o atacará dependiento lo que corresponda. Actualizará el juego según los efectos del movimiento del
 * personaje, matar rivales, actualizar la matriz, restar vida, etc.
 */
void jugar(juego_t* juego, char bando, int posicion_personaje);

#endif /* __BATALLA_H__ */