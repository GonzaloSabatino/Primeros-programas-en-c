#include "perfil.h"
#include "batalla.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#define MAX_FILAS_ENEMIGOS 500
#define MAX_COLUMNAS_ENEMIGOS 500

const char ROHAN = 'R';
const char ISENGARD = 'I';
const char HOMBRE = 'H';
const char ELFO = 'E';
const char ORCO = 'O';
const char URUK = 'U';
const char VACIO = ' ';

const int CANTIDAD_MINIMA_RANDOM = 0;
const int CANTIDAD_MAXIMA_RANDOM = 5;

const int FILA_MINIMA = 4;
const int FILA_MINIMA_ROHAN = 5;
const int FILA_MAXIMA_ROHAN = 8;
const int FILA_MINIMA_ISENGARD = 1;
const int FILA_MAXIMA_ISENGARD = 4;
const int COLUMNA_MINIMA = 5;
const int FILA_POR_DESCARTE_ROHAN = 6;
const int FILA_POR_DESCARTE_ISENGARD = 3;
const int FILA_HOMBRE = 9;
const int FILA_ORCO = 0;
const int COLUMNA_MAXIMA = 9;

const int LLEGADA_MAXIMA = 5;

const int DISTANCIA_TERRESTRES = 1;
const int DISTANCIA_ARQUEROS = 3;

const int UN_JUGADOR = 1;
const int DOS_JUGADORES = 2;

const int LIMITE_ENERGIA = 10;
const int ENERGIA_MINIMA_ELFO = 8;
const int ENERGIA_MINIMA_URUK = 8;
const int ENERGIA_MINIMA_HOMBRE = 3;
const int ENERGIA_MINIMA_ORCO = 3;
const int ENERGIA_COMIENZO = 5;

const int LLEGADAS_COMIENZO = 0;
const int CANT_PERSONAJES_COMIENZO = 3;

const int VIDA_ELFO = 200;
const int VIDA_URUK = 200;
const int VIDA_HOMBRE = 100;
const int VIDA_ORCO = 100;
const int VIDA_MUERTO = 0;
const int ATAQUE_ELFO = 10;
const int ATAQUE_URUK = 10;
const int ATAQUE_HOMBRE = 50;
const int ATAQUE_ORCO = 50;
const int PRIMER_ELFO = 0;
const int SEGUNDO_ELFO = 1;
const int TERCER_ELFO = 2;
const int PRIMER_URUK = 0;
const int SEGUNDO_URUK = 1;
const int TERCER_URUK = 2;

const int POSICION_ELFO_UNO = 8;
const int POSICION_ELFO_DOS = 7;
const int POSICION_ELFO_TRES = 6;
const int POSICION_URUK_UNO = 1;
const int POSICION_URUK_DOS = 2;
const int POSICION_URUK_TRES = 3;

const int LLEGADA_ROHAN = 0;
const int LLEGADA_ISENGARD = 9;

const int POSITIVO_MINIMO = 0;
const int NEGATIVO = -1;

const int INTENSIDAD_MAXIMA = 10;

const int TURNO_INICIAL = 0;

/*
 * Pre-condiciones: Los valores de la energía de cada bando y la cantidad de turnos deben estar inicializados.
 * Post-condiciones: Imprimirá cuál es el valor de ambas cosas aclaradas en las precondiciones, de cada usuario.
 */
void imprimir_datos_de_usuarios(juego_t* juego){
	if(juego->usuario_1_es_rohan){
		printf("Usuario 1(Rohan): Energía->%i || Cantidad de llegadas->%i\n", juego->energia_rohan, juego->llegadas_rohan);
		printf("Usuario 2(Isengard): Energía->%i || Cantidad de llegadas->%i\n", juego->energia_isengard, juego->llegadas_isengard);
	}else{
		printf("Usuario 1(Isengard): Energía->%i || Cantidad de llegadas->%i\n", juego->energia_isengard, juego->llegadas_isengard);
		printf("Usuario 2(Rohan): Energía->%i || Cantidad de llegadas->%i\n", juego->energia_rohan, juego->llegadas_rohan);
	}
}

/*
 * Pre-condiciones: Los enteros deben estar correctamente cargados.
 * Post-condiciones: Cargará al terreno los personajes que se encuentran en el vector pasado.
 */
void cargar_vector_en_terreno(juego_t* juego, int tope, personaje_t* vector, int* fila, int* columna){
	for(int i = 0; i < tope; i++){
		*fila = vector[i].fila;
		*columna = vector[i].columna;

		juego->terreno[*fila][*columna] = vector[i].codigo;
	}
}

/*
 * Pre-condiciones: No tiene.
 * Post-condiciones: Pondrá el terreno en blanco y colocará los jugadores de cada bando por cada vez que sea llamada.
 */
void actualizar_terreno(juego_t* juego){
	int fila;
	int columna;

	for(int fil = 0; fil < MAX_TERRENO_FIL; fil++){
		for(int col = 0; col < MAX_TERRENO_COL; col++){
			juego->terreno[fil][col] = VACIO;
		}
	}

	cargar_vector_en_terreno(juego, juego->cantidad_rohan, juego->rohan, &fila, &columna);
	cargar_vector_en_terreno(juego, juego->cantidad_isengard, juego->isengard, &fila, &columna);
}

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Limpiará la pantalla y mostrará el terreno de juego.
 */
void dibujar_terreno(juego_t* juego){
	system("clear");

	printf("TURNO: %i\n", juego->cantidad_turnos);
	imprimir_datos_de_usuarios(juego);

	actualizar_terreno(juego);

	printf("________________________________________\n");
	printf("	     LLEGADA ROHAN\n");
	printf("________________________________________\n");
	for(int fil = 0; fil < MAX_TERRENO_FIL; fil++){
		for(int col = 0; col < MAX_TERRENO_COL; col++){
			if(juego->terreno[fil][col] != HOMBRE && juego->terreno[fil][col] != ELFO && juego->terreno[fil][col] != ORCO && juego->terreno[fil][col] != URUK){
				printf(" %c |", VACIO);
			}else{
				printf(" %c |", juego->terreno[fil][col]);
			}
		}
		printf(" %i\n", fil);
	}
	printf(" 0   1   2   3   4   5   6   7   8   9  \n");
	printf("________________________________________\n");
	printf("	     LLEGADA ISENGARD\n");
	printf("________________________________________\n\n");
}

/*
 * Pre-condiciones: Los enteros deben estar correctamente cargados.
 * Post-condiciones: Asignará a rohan y a isengard su intensidad según la cargada por el usuario
 */
void asignar_a_rohan_o_isengard(juego_t* juego, int intensidad_usuario, int intensidad_otro_usuario, int numero_random){
	juego->plus_rohan = intensidad_usuario * numero_random;
	juego->plus_isengard = intensidad_otro_usuario * numero_random;
}

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Cargará los datos relacionados con el perfil del usuario, actualizando si el usuario 1 es de rohan o isengard.
 */
void ubicar_usuario(juego_t* juego){
	int intensidad_1;
	int intensidad_2;
	char tipo_1;
	int numero_random;

	numero_random = rand() % CANTIDAD_MAXIMA_RANDOM + CANTIDAD_MINIMA_RANDOM;

	perfil(&tipo_1, &intensidad_1);

	intensidad_2 = INTENSIDAD_MAXIMA - intensidad_1;
	juego->cantidad_turnos = TURNO_INICIAL;
	if(tipo_1 == ROHAN){
		juego->usuario_1_es_rohan = true;
		asignar_a_rohan_o_isengard(juego, intensidad_1, intensidad_2, numero_random);
	}else{
		juego->usuario_1_es_rohan = false;
		asignar_a_rohan_o_isengard(juego, intensidad_2, intensidad_1, numero_random);
	}
}

/*
 * Pre-condiciones: La fila minima del bando deberá estar inicializada dependiendo del valor del que se quiera partir.
 * Post-condiciones: Le asignará una fila y columna a los arqueros (elfos y uruk-hais) de manera aleatoria, según los parámetros pasados.
 */
void posicionar_arqueros(int *fila, int *columna, int fila_minima_bando){
	*fila = rand() % FILA_MINIMA + fila_minima_bando;
	*columna = rand() % COLUMNA_MAXIMA + CANTIDAD_MINIMA_RANDOM;
}

/*
 *	Pre-condiciones:  Tanto el juego como la fila y columna del arquero que se desee verificar, deben estar correctamente inicializadas (numero positivo, dentro del terreno).
 *	Post-condiciones: Posicionará el personaje del bando recibido (elfo o uruk-hai), en una parte válida del terreno, si no lo estaba antes, en el inicio del juego (donde no hay más personajes que los 3 arqueros por bando).
 */
void validar_posicion_arqueros_iniciales(personaje_t personajes[MAX_PERSONAJES], int tope, int *fila, int *columna, char codigo_personaje){
	int i = 0;

	while(i < tope){
		if(personajes[i].fila == *fila && personajes[i].columna == *columna && personajes[i].codigo == codigo_personaje){
			posicionar_arqueros(fila, columna, FILA_MINIMA_ROHAN);
			i = 0;
		}
		i++;
	}	
}

/*
 * Pre-condiciones: No tiene.
 * Post-condiciones: Asignará una fila y una columna a los parámetros ingresados.
 */
void ingresar_datos(int* fila, int* columna){
	printf("Ingrese fila:\n");
	scanf("%i", fila);
	printf("Ingrese columna (de 0 a 9):\n");
	scanf("%i", columna);
}

/*
 * Pre-condiciones: Todos los parámetros deben estar inicializados.
 * Post-condiciones: Asignará una fila por descarte si la fila no era permitida.
 */
void posicionar_fila_por_descarte(int* fila, int fila_maxima, int fila_minima, int fila_por_descarte){
	if(*fila > fila_maxima || *fila < fila_minima){
			*fila = fila_por_descarte;
	}
}

/*
 * Pre-condiciones: Recibe números enteros positivos.
 * Post-condiciones: Posicionará el personaje recibido en una parte válida del terreno.
 */
void datos_para_validar_arqueros(juego_t* juego, char bando, int* fila, int* columna, int fila_maxima, int fila_minima, int fila_por_descarte, char codigo_companiero){
	ingresar_datos(fila, columna);

	posicionar_fila_por_descarte(fila, fila_maxima, fila_minima, fila_por_descarte);
	while(juego->terreno[*fila][*columna] == codigo_companiero){
		posicionar_arqueros(fila, columna, fila_minima);
	}
}

/*
 *	Pre-condiciones:  Tanto el juego como la fila y columna del arquero que se desee verificar, deben estar correctamente inicializadas (numero positivo, dentro del terreno).
 *	Post-condiciones: Posicionará el personaje del bando recibido (elfo o uruk-hai), en una parte válida del terreno, si no lo estaba antes.
 */
void validar_posicion_arqueros(juego_t* juego, char bando, int *fila, int *columna){
	if(bando == ROHAN){
		datos_para_validar_arqueros(juego, ROHAN, fila, columna, FILA_MAXIMA_ROHAN, FILA_MINIMA_ROHAN, FILA_POR_DESCARTE_ROHAN, ELFO);
	}else{
		datos_para_validar_arqueros(juego, ISENGARD, fila, columna, FILA_MAXIMA_ISENGARD, FILA_MINIMA_ISENGARD, FILA_POR_DESCARTE_ISENGARD, URUK);
	}
}

/*
 * Pre-condiciones: Recibe sus parámetros correctamente cargados.
 * Post-condiciones: Asignará un codigo, fila y columna a cada personaje inicial que sea recibido
 */
void cargar_en_vector_personajes_iniciales(personaje_t* personaje, char codigo_a_cargar, int fila_a_cargar, int columna_a_cargar){
	personaje->codigo = codigo_a_cargar;
	personaje->fila = fila_a_cargar;
	personaje->columna = columna_a_cargar;
}

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Cargará cada personaje inicial al terreno, actualizando los vectores de rohan e isengard.
 */
void cargar_inicio(juego_t* juego){
	int fila;
	int columna;

	for(int i = 0; i < CANT_PERSONAJES_COMIENZO; i++){
		posicionar_arqueros(&fila, &columna, FILA_MINIMA_ROHAN);
		validar_posicion_arqueros_iniciales(juego->rohan, juego->cantidad_rohan, &fila, &columna, ELFO);
		cargar_en_vector_personajes_iniciales(&(juego->rohan[i]), ELFO, fila, columna);
		posicionar_arqueros(&fila, &columna, FILA_MINIMA_ISENGARD);
		validar_posicion_arqueros_iniciales(juego->isengard, juego->cantidad_isengard, &fila, &columna, URUK);
		cargar_en_vector_personajes_iniciales(&(juego->isengard[i]), URUK, fila, columna);
	}
}

/*
 * Pre-condiciones: Tanto la vida, como el plus y el ataque del personaje deben estar inicializados con numeros enteros positivos.
 * Post-condiciones: Asignará al personaje cuál es su vida y cuál es su ataque.
 */
void calcular_vida_ataque(personaje_t* personaje, int vida_personaje, int ataque_personaje, int plus_personaje){
	personaje->vida = vida_personaje - plus_personaje;
	personaje->ataque = ataque_personaje + plus_personaje;
}

/*
 * Pre-condiciones: No tiene.
 * Post-condiciones: Asignará la energía, llegadas y cantidad de personajes según fueron planteadas las condiciones iniciales.
 */
void poner_valores_comienzo(int *energia, int *llegadas, int *cantidad_personajes){
	*energia = ENERGIA_COMIENZO;
	*llegadas = LLEGADAS_COMIENZO;
	*cantidad_personajes = CANT_PERSONAJES_COMIENZO;
}

/*
 * Pre-condiciones: No tiene
 * Post-condiciones: Inicializará todos los valores del juego, dejándolo en un estado inicial válido.
 */
void inicializar_juego(juego_t *juego){
	actualizar_terreno(juego);
	srand((unsigned)time(NULL));
	ubicar_usuario(juego);

	cargar_inicio(juego);

	poner_valores_comienzo(&(juego->energia_rohan), &(juego->llegadas_rohan), &(juego->cantidad_rohan));
	poner_valores_comienzo(&(juego->energia_isengard), &(juego->llegadas_isengard), &(juego->cantidad_isengard));

	for(int i = 0; i < CANT_PERSONAJES_COMIENZO; i++){
		calcular_vida_ataque(&(juego->rohan[i]), VIDA_ELFO, ATAQUE_ELFO, juego->plus_rohan);
		calcular_vida_ataque(&(juego->isengard[i]), VIDA_URUK, ATAQUE_URUK, juego->plus_isengard);
	}
}

/*
 * Pre-condiciones: El personaje recibido debe estar correctamente cargado.
 * Post-condiciones: Colocará en el terreno el personaje recibido.
 */
void colocar_en_terreno(juego_t* juego, personaje_t personaje){
	juego->terreno[personaje.fila][personaje.columna] = personaje.codigo;
}

/*
 * Pre-condiciones: El personaje recibido debe estar correctamente cargado.
 * Post-condiciones: Sumará uno a la cantidad de personajes que tiene rohan o a la cantidad de personajes que tiene isengard, dependiendo de cuál sea el personaje recibido.
 */
void sumar_cantidad_personajes(juego_t* juego, personaje_t personaje){
	if(personaje.codigo == ELFO || personaje.codigo == HOMBRE){
		juego->cantidad_rohan++;
	}else{
		juego->cantidad_isengard++;
	}
}

/*
 * Pre-condiciones: Recibirá un personaje, con todos sus campos correctamente cargados.
 * Post-condiciones: Dará de alta en el juego al personaje cargado, sumándolo al vector correspondiente,
 * posicionándolo también en la matriz.
 */
void posicionar_personaje(juego_t* juego, personaje_t personaje){
	sumar_cantidad_personajes(juego, personaje);
	colocar_en_terreno(juego, personaje);
}

/*
 * Pre-condiciones: Todos los parámetros de la función deben estar correctamente inicializados.
 * Post-condiciones: Eliminará al personaje recibido de su vector correspondiente (rohan o isengard), colocando al último guerrero del vector en su posición.
 */
void eliminar_personaje(personaje_t *personaje, personaje_t ultimo_personaje){
	*personaje = ultimo_personaje;
}

/*
 *	Pre-condiciones: Recibe la posicion y el bando, correctamente cargados.
 *	Post-condiciones: En caso de que el personaje se encuentre sin vida, lo elimina del juego (tanto del terreno como de su correspondiente vector).
 */
void personaje_muerto(personaje_t personajes[MAX_PERSONAJES], int* cantidad_personajes){
	for(int i = 0; i < *cantidad_personajes; i++){
		if(personajes[i].vida <= VIDA_MUERTO){
			eliminar_personaje(&(personajes[i]), personajes[*cantidad_personajes - 1]);
			*cantidad_personajes-=1;
		}
	}
}

/*
 * Pre-condiciones: No tiene.
 * Post-condiciones: Buscará si hay algun personaje con vida por debajo de la permitida; si es así, procederá a eliminarlo.
 */
void buscar_personaje_muerto(juego_t* juego){
	personaje_muerto(juego->rohan, &(juego->cantidad_rohan));
	personaje_muerto(juego->isengard, &(juego->cantidad_isengard));
}

/*
 *	Pre-condiciones: Recibe todos los parámetros correctamente cargados.
 *	Post-condiciones: Restará vida al personaje que se encuentre en la fila y columna recibidos. 
 */
void aplicar_ataque(personaje_t atacante, personaje_t* enemigo_atacado){
	enemigo_atacado->vida -= atacante.ataque;
}

/*
 * Pre-condiciones: Las filas y columnas recibidas deben estar cargadas con un número entero.
 * Post-condiciones: Devolverá la distancia que se halla al restar ambas columnas sumadas a ambas filas restadas, todo de forma positiva.
 */
int distancia_manhatan(int fila1, int fila2, int columna1, int columna2){
	int num_positivo;
	int resta_filas = fila1 - fila2;
	int resta_columnas = columna1 - columna2;

	if(resta_filas < POSITIVO_MINIMO){
		resta_filas *= NEGATIVO;
	}
	if(resta_columnas < POSITIVO_MINIMO){
		resta_columnas *= NEGATIVO;
	}

	num_positivo = resta_filas + resta_columnas;

	return num_positivo;
}

/*
 * Pre-condiciones: No tiene.
 * Post-condiciones: Realizará el ataque del personaje terrestre (hombre u orco), descontándole vida al enemigo.
 */
void ataque_terrestres(bool* ataco, personaje_t personaje, personaje_t* enemigo){
	int distancia = distancia_manhatan(personaje.fila, enemigo->fila, personaje.columna, enemigo->columna);
	if(distancia <= DISTANCIA_TERRESTRES){
		aplicar_ataque(personaje, enemigo);
		*ataco = true;
	}else if(personaje.fila == enemigo->fila - 1 || personaje.fila == enemigo->fila + 1){
		if(personaje.columna == enemigo->columna - 1 || personaje.columna == enemigo->columna + 1){
			aplicar_ataque(personaje, enemigo);
			*ataco = true;
		}
	}
}

/*
 * Pre-condiciones: Recibe todos sus parámetros correctamente cargados.
 * Post-condiciones: Llamará a las funciones relacionadas con el ataque del terrestre (Hombre u Orco) recibido.
 */
void llamar_funciones_ataque_terrestres(bool* ataco, personaje_t personaje, personaje_t enemigos[MAX_PERSONAJES], int cantidad_enemigos){
	int j = 0;
	while(!*ataco && (j < cantidad_enemigos)){
		ataque_terrestres(ataco, personaje, &enemigos[j]);
		j++;
	}
}

/*
 * Pre-condiciones: Recibe sus parámetros correctamente cargados.
 * Post-condiciones: Llamará a las funciones relacionadas con el arquero (Elfo o Uruk-hai) recibido.
 */
void llamar_funciones_ataque_arqueros(personaje_t personaje, personaje_t enemigos[MAX_PERSONAJES], int cantidad_enemigos, bool* ataco){
	int distancia;
	for(int i = 0; i < cantidad_enemigos; i++){
		distancia = distancia_manhatan(personaje.fila, enemigos[i].fila, personaje.columna, enemigos[i].columna);
		if(distancia <= DISTANCIA_ARQUEROS){
			aplicar_ataque(personaje, &enemigos[i]);
			*ataco = true;
		}
	}
}

/*
 *	Pre-condiciones: Recibe los parámetros correctamente cargados.
 *	Post-condiciones: Realizará un ataque a cada enemigo que tenga en su rango el personaje recibido. 
 */
void atacar(juego_t* juego, char bando, int posicion_personaje, int fila, int columna, bool *ataco){
	*ataco = false;

	if(bando == ROHAN){
		if(juego->rohan[posicion_personaje].codigo == HOMBRE){
			llamar_funciones_ataque_terrestres(ataco, juego->rohan[posicion_personaje], juego->isengard, (juego->cantidad_isengard));
		}else{
			llamar_funciones_ataque_arqueros(juego->rohan[posicion_personaje], juego->isengard, juego->cantidad_isengard, ataco);
		}
	}else{
		if(juego->isengard[posicion_personaje].codigo == ORCO){
			llamar_funciones_ataque_terrestres(ataco, juego->isengard[posicion_personaje], juego->rohan, (juego->cantidad_rohan));
		}else{
			llamar_funciones_ataque_arqueros(juego->isengard[posicion_personaje], juego->rohan, juego->cantidad_rohan, ataco);
		}
	}
}

/*
 * Pre-condiciones: Recibe todos los parámetros correctamente cargados.
 * Post-condiciones: Sumará uno en caso de que el personaje ingresado se encuentre en la posición de llegada de su bando.
 */
void sumar_llegada(personaje_t *personaje, personaje_t ultimo_personaje, int *cantidad_personajes, int posicion_llegada_bando, int *llegadas){
	if(personaje->fila == posicion_llegada_bando){
		(*llegadas)++;
		eliminar_personaje(personaje, ultimo_personaje);
		(*cantidad_personajes)--;
	}
}

/*
 * Pre-condiciones: Recibe sus parámetros correctamente cargados.
 * Post-condiciones: Llamará a las funciones relacionadas con mover el personaje recibido.
 */
void datos_de_mover(personaje_t* personaje, personaje_t ultimo_personaje, int *cantidad_personajes_bando, int posicion_llegada_bando, int *cantidad_llegadas_bando, int variable_sumar_fila){
	personaje->fila += variable_sumar_fila;
	sumar_llegada(personaje, ultimo_personaje, cantidad_personajes_bando, posicion_llegada_bando, cantidad_llegadas_bando);
		
}

/*
 *	Pre-condiciones: Recibe los parámetros correctamente cargados, con un código de un compañero que tiene cerca por referencia.
 *	Post-condiciones: Realizará un movimiento, si el personaje es el correcto, actualizando tanto el terreno como el vector del bando correspondiente.
 */
void mover(juego_t* juego, char bando, int posicion_personaje){
	if(bando == ROHAN){
		if(juego->rohan[posicion_personaje].codigo == HOMBRE){
			datos_de_mover(&(juego->rohan[posicion_personaje]), juego->rohan[juego->cantidad_rohan - 1], &(juego->cantidad_rohan), LLEGADA_ROHAN, &(juego->llegadas_rohan), -1);
		}
	}else{
		if(juego->isengard[posicion_personaje].codigo == ORCO){	
			datos_de_mover(&(juego->isengard[posicion_personaje]), juego->isengard[juego->cantidad_isengard - 1], &(juego->cantidad_isengard), LLEGADA_ISENGARD, &(juego->llegadas_isengard), 1);
		}
	}
}

/*
 * Pre-condiciones: Recibe sus parámetros correctamente cargados.
 * Post-condiciones: Llamará a las funciones relacionadas con jugar, del personaje recibido.
 */
void datos_de_jugar(juego_t* juego, char bando, int posicion_personaje, int fila, int columna, bool* ataco){
	atacar(juego, bando, posicion_personaje, fila, columna, ataco);
	buscar_personaje_muerto(juego);
	if(!*ataco){
		mover(juego, bando, posicion_personaje);
	}
}

/*
 * Pre-condiciones: Recibe un bando en la posición posicion_personaje correctamente cargada, al igual que el bando como un caracter.
 * Post-condiciones: Realizará la jugada del personaje del bando recibido.
 * Se moverá o atacará dependiento lo que corresponda. Actualizará el juego según los efectos del movimiento del
 * personaje, matar rivales, actualizar la matriz, restar vida, etc.
 */
void jugar(juego_t* juego, char bando, int posicion_personaje){
	bool ataco;

	if(bando == ROHAN){
		datos_de_jugar(juego, ROHAN, posicion_personaje, juego->rohan[posicion_personaje].fila, juego->rohan[posicion_personaje].columna, &ataco);
	}else{
		datos_de_jugar(juego, ISENGARD, posicion_personaje, juego->isengard[posicion_personaje].fila, juego->isengard[posicion_personaje].columna, &ataco);
	}
	actualizar_terreno(juego);
}

/*
 * Pre-condiciones: Recibe energía entera y positiva.
 * Post-condiciones: En caso de poderse, sumará uno a la cantidad de energía, del bando, recibida.
 */
int energia_sumada(int energia){
	if(energia < LIMITE_ENERGIA){
		energia++;
	}
	return energia;
}

/*
 *	Pre-condiciones: No tiene. 
 *	Post-condiciones: Sumará uno a la cantidad de energía del jugador correspondiente, en caso de no haber pasado el límite permitido de la misma. 
 */
void sumar_energia(juego_t* juego){
	juego->energia_rohan = energia_sumada(juego->energia_rohan);
	juego->energia_isengard = energia_sumada(juego->energia_isengard);
}

/*
 *	Pre-condiciones:  Recibe un carácter, correctamente cargado.
 *	Post-condiciones: Devolverá true en caso de que se tenga suficiente energía para utilizar el personaje que se quiere, false en caso de no ser suficiente.
 */
bool energia_valida(int energia_bando, int energia_personaje){
	bool energia_suficiente = false;
	if(energia_bando >= energia_personaje){
		energia_suficiente = true;
	}

	return energia_suficiente;
}

/*
 * Pre-condiciones: La fila recibida debe ser un número entero positivo dentro del rango permitido.
 * Post-condiciones: Asignará una fila y una columna al personaje terrestre (hombre u orco) ingresado.
 */
void posicionar_terrestres(personaje_t* personaje, int fila_personaje){
	personaje->fila = fila_personaje;

	printf("Ingrese columna de su personaje, recuerde hacerlo de 0 a 9\n");
	scanf("%i", &(personaje->columna));

	while(personaje->columna > COLUMNA_MAXIMA){
		printf("Ingrese la columna nuevamente, recuerde hacerlo de 0 a 9\n");
		scanf("%i", &personaje->columna);
	}
}

/*
 * Pre-condiciones: Recibirá números enteros positivos y un carácter personaje que debe estar correctamente ingresado.
 * Post-condiciones: Asignará una vida, un ataque y un código al personaje recibido.
 */
void cargar_personaje(personaje_t* personaje, char codigo_personaje, int vida_personaje, int ataque_personaje){
	personaje->vida = vida_personaje;
	personaje->ataque = ataque_personaje;
	personaje->codigo = codigo_personaje;
}

/*
 * Pre-condiciones: Ambas energías deben ser números enteros, siendo la energía mínima un número entero positivo.
 * Post-condiciones: En caso de tener energía como para restar, restará la energía del personaje que se utilizará.
 */
void restar_energia(int *energia_a_restar, int energia_minima){
	if(*energia_a_restar >= energia_minima){
		*energia_a_restar -= energia_minima;
	}
}

/*
 * Pre-condiciones: Recibe sus parámetros correctamente cargados, en los cuales se recibe el personaje por valor y el mismo personaje por referencia, para poder llamar a distintas funciones.
 * Post-condiciones: Llamará a las funciones relacionadas con cargar el personaje terrestre (Hombre u Orco) recibido al juego, correctamente.
 */
void datos_para_terrestres(juego_t* juego, int *energia_bando, int energia_personaje, personaje_t *personaje, personaje_t personaje_sin_referencia, int vida, int ataque, int fila_personaje, char codigo_personaje){
	int energia_aux = *energia_bando;
	bool puede_cargar = energia_valida(energia_aux, energia_personaje);
	if(puede_cargar){	
		cargar_personaje(personaje, codigo_personaje, vida, ataque);
		posicionar_terrestres(personaje, fila_personaje);
		personaje_sin_referencia = *personaje;
		posicionar_personaje(juego, personaje_sin_referencia);
		restar_energia(energia_bando, energia_personaje);
	}
}

/*
 * Pre-condiciones: Recibe sus parámetros correctamente cargados, en los cuales se recibe el personaje por valor y el mismo personaje por referencia, para poder llamar a distintas funciones.
 * Post-condiciones: Llamará a las funciones relacionadas con cargar el personaje arquero (Elfo o Uruk-hai) recibido al juego, correctamente.
 */
void datos_para_arqueros(juego_t* juego, char bando, personaje_t* personaje, personaje_t personaje_sin_referencia, int vida, int ataque, char codigo_personaje, int *energia_bando, int energia_personaje, int fila_minima_bando){
	int fila;
	int columna;
	int energia_aux = *energia_bando;
	bool puede_cargar = energia_valida(energia_aux, energia_personaje);
	if(puede_cargar){
		cargar_personaje(personaje, codigo_personaje, vida, ataque);
		posicionar_arqueros(&fila, &columna, fila_minima_bando);
		validar_posicion_arqueros(juego, bando, &fila, &columna);
		personaje->columna = columna;
		personaje->fila = fila;
		personaje_sin_referencia = *personaje;
		posicionar_personaje(juego, personaje_sin_referencia);				
		restar_energia(energia_bando, energia_personaje);				
	}
}

/*
 *	Pre-condiciones: Recibe un carácter, correctamente cargado. Ingresar números enteros y positivos.
 *	Post-condiciones: En caso de que el jugador desee posicionar un personaje, verificará si puede hacerlo y, en caso de ser afirmativo, lo actualizará tanto al terreno como al vector del personaje correspondiente.
 */
void preguntar_personaje(juego_t* juego, char bando){
	char codigo_rohan;
	char codigo_isengard;
	int tope;

	srand((unsigned)time(NULL));
	if(bando == ROHAN){
		tope = juego->cantidad_rohan;
		printf("Rohan: Qué personaje desea cargar?\nH (hombre), E (elfo), N (nada)\n");
		scanf(" %c", &codigo_rohan);	

		if(codigo_rohan == HOMBRE){
			datos_para_terrestres(juego, &(juego->energia_rohan), ENERGIA_MINIMA_HOMBRE, &(juego->rohan[tope]), juego->rohan[tope], VIDA_HOMBRE - juego->plus_rohan, ATAQUE_HOMBRE + juego->plus_rohan, FILA_HOMBRE, HOMBRE);
		}else if(codigo_rohan == ELFO){
			datos_para_arqueros(juego, ROHAN, &(juego->rohan[tope]), juego->rohan[tope], VIDA_ELFO - juego->plus_rohan, ATAQUE_ELFO + juego->plus_rohan, ELFO, &(juego->energia_rohan), ENERGIA_MINIMA_ELFO, FILA_MINIMA_ROHAN);
		}	
	}else{
		tope = juego->cantidad_isengard;
		printf("Isengard: Qué personaje desea cargar?\nO (orco), U (uruk), N (nada)\n");
		scanf(" %c", &codigo_isengard);

		if(codigo_isengard == ORCO){
			datos_para_terrestres(juego, &(juego->energia_isengard), ENERGIA_MINIMA_ORCO, &(juego->isengard[tope]), juego->isengard[tope], VIDA_ORCO - juego->plus_isengard, ATAQUE_ORCO + juego->plus_isengard, FILA_ORCO, ORCO);
		}else if(codigo_isengard == URUK){
			datos_para_arqueros(juego, ISENGARD, &(juego->isengard[tope]), juego->isengard[tope], VIDA_URUK - juego->plus_isengard, ATAQUE_URUK + juego->plus_isengard, URUK, &(juego->energia_isengard), ENERGIA_MINIMA_URUK, FILA_MINIMA_ISENGARD);
		}
			
	}	
}

/*
 *	Pre-condiciones: Recibe un carácter correctamente cargado.
 *	Post-condiciones: Posicionará automáticamente el hombre/orco pertenecientes al turno de la máquina.
 */
void posicionar_maquina(personaje_t* personaje, int fila_personaje){
	srand((unsigned)time(NULL));

	personaje->fila = fila_personaje;
	personaje->columna = rand()% COLUMNA_MAXIMA + COLUMNA_MINIMA;	
}

/*
 * Pre-condiciones: Recibe sus parámetros correctamente cargados.
 * Post-condiciones: Llamará a las funciones relacionadas con tomar_datos_maquina, para poder cargar el personaje al juego correctamente.
 */
void cargar_maquina(juego_t* juego, personaje_t* personaje, personaje_t personaje_sin_referencia, int* energia_bando, int energia_personaje, char codigo_personaje, int vida, int ataque, int fila_personaje){
	if(*energia_bando >= energia_personaje){
		cargar_personaje(personaje, codigo_personaje, vida, ataque);
		posicionar_maquina(personaje, fila_personaje);
		personaje_sin_referencia = *personaje;
		posicionar_personaje(juego, personaje_sin_referencia);
		restar_energia(energia_bando, energia_personaje);
	}
}

/*
 * Pre-condiciones: No tiene.
 * Post-condiciones: Cargará el personaje de la maquina, lo posicionará, le restará energía, actualizará el terreno.
 */
void tomar_datos_maquina(juego_t* juego, char bando){
	if(bando == ROHAN){
		cargar_maquina(juego, &(juego->rohan[juego->cantidad_rohan]),juego->rohan[juego->cantidad_rohan], &(juego->energia_rohan), ENERGIA_MINIMA_HOMBRE, HOMBRE, VIDA_HOMBRE - juego->plus_rohan, ATAQUE_HOMBRE + juego->plus_rohan, FILA_HOMBRE);
	}else{
		cargar_maquina(juego, &(juego->isengard[juego->cantidad_isengard]),juego->isengard[juego->cantidad_isengard], &(juego->energia_isengard), ENERGIA_MINIMA_ORCO, ORCO, VIDA_ORCO - juego->plus_isengard, ATAQUE_ORCO + juego->plus_isengard, FILA_ORCO);
	}
}

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Devolverá true en caso de que no haya ningún ganador, false en caso de que un jugador haya llegado con 5 o más personajes a la meta.
 */
bool sigue_juego(juego_t juego){
	return (juego.llegadas_rohan < LLEGADA_MAXIMA && juego.llegadas_isengard < LLEGADA_MAXIMA);
}

/*
 * Pre-condiciones: Recibirá todos sus parámetros correctamente cargados.
 * Post-condiciones: Dibujará el terreno de juego y realizará la jugada de cada personaje que ya se encuentra posicionado.
 */
void datos_para_turnos(juego_t* juego, char bando, int cantidad_personajes){
	dibujar_terreno(juego);

	for(int i = 0; i < cantidad_personajes; i++){
		jugar(juego, bando, i);
	}
}

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Realizará la jugada de cada jugador (atacar, mover, posicionar, eliminar rivales, sumar llegadas), luego sumará uno a la energía de cada bando.
 */
void turno_2_jugadores(juego_t* juego){
	datos_para_turnos(juego, ROHAN, juego->cantidad_rohan);
	preguntar_personaje(juego, ROHAN);

	datos_para_turnos(juego, ISENGARD, juego->cantidad_isengard);
	preguntar_personaje(juego, ISENGARD);

	sumar_energia(juego);
	juego->cantidad_turnos++;
}

/*
 *	Pre-condiciones: Recibe un carácter correctamente cargado.
 *	Post-condiciones: Permitirá únicamente que el jugador 1 disponga de su turno para realizar su jugada (atacar, mover, posicionar, eliminar rivales, sumar llegadas), pasará al turno de la máquina, luego sumará uno a la energía de cada bando.
 */
void turno_1_jugador(juego_t* juego){
	if(juego->usuario_1_es_rohan){
		datos_para_turnos(juego, ROHAN, juego->cantidad_rohan);
		preguntar_personaje(juego, ROHAN);

		datos_para_turnos(juego, ISENGARD, juego->cantidad_isengard);
		tomar_datos_maquina(juego, ISENGARD);

		sumar_energia(juego);
		juego->cantidad_turnos++;
	}else{
		datos_para_turnos(juego, ROHAN, juego->cantidad_rohan);
		tomar_datos_maquina(juego, ROHAN);

		datos_para_turnos(juego, ISENGARD, juego->cantidad_isengard);
		preguntar_personaje(juego, ISENGARD);

		sumar_energia(juego);
		juego->cantidad_turnos++;
	}
}

/*
 * Pre-condiciones: El número recibido debe ser un entero positivo.
 * Post-condiciones: Devolverá el número recibido, pero dentro del rango permitido.
 */
void validar_decision_jugadores(int *numero_validado){
	while(*numero_validado != UN_JUGADOR && *numero_validado != DOS_JUGADORES){
		printf("Ha ingresado mal el número/ha salido del rango, por favor vuelva a ingresar qué opción le gustaría:\nIngrese 1 si quiere jugar contra la máquina\nIngrese 2 si quiere jugar 1 vs 1\n");
		scanf("%i", numero_validado);
	}
}

/*
 * Pre-condiciones: El número debe ser 1 o 2.
 * Post-condiciones: 
 */
int cantidad_jugadores_decididos(int numero_de_jugadores){
	if(numero_de_jugadores == UN_JUGADOR){
		return DOS_JUGADORES;
	}else{
		return UN_JUGADOR;
	}
}

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Preguntará al usuario 1 si quiere jugar contra otro usuario o si desea hacerlo contra la máquina.
 */
void decidir_cuantos_jugadores(int *cantidad_jugadores){
	int numero_validado;

	system("clear");

	printf("Como quiere jugar:\n1 (usuario 1 vs usuario 2)\n2 (contra la máquina)\n\n");
	scanf("%i", &numero_validado);

	validar_decision_jugadores(&numero_validado);	

	*cantidad_jugadores = cantidad_jugadores_decididos(numero_validado);
}