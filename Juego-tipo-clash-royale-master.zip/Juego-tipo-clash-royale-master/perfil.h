#ifndef __PERFIL_H__
#define __PERFIL_H__

/*
** Pre
** Post
*/
void perfil(char *tipo, int *intensidad);

#endif