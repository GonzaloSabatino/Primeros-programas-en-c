#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include "perfil.h"
#include "batalla.h"

const int DOS_JUGADOR = 2;
const int LLEGADAS_TOTALES = 5;
const char SI = 's';

int main(){
	int cant_jugadores;
	juego_t juego;
	char decision;

	system("clear");

	printf("			BIEVENIDO/S A HELM ROYALE\n\n");
	printf("Instrucciones:\nEl juego consiste en intentar llegar con 5 jugadores de su bando a la última fila del bando contrario, en caso de hacerlo, ganarás\n");
	printf("Habrá dos bandos disponibles que se obtendrán luego de hacerle un cuestionario al usuario 1, un usuario puede defender a Rohan o ser Isengard\n");
	printf("Cada bando tiene dos personajes, uno terrestre (hombre u orco) que atacan solo a un personaje por turno, pero son los únicos que se mueven, y un arquero (elfo o uruk-hai) que únicamente atacará a personajes en un rango de 3.\n");
	printf("\nEstá/n listo/s para comenzar a jugar?(s)\n");
	scanf(" %c", &decision);

	while(decision != SI){
		printf("Ahora lo está?\n");
		scanf(" %c", &decision);
	}

	system("clear");

	printf("Cuestionario:\n");
	//lo pongo así porque tuve que comentar los printf del perfil.c, no pasaban las pruebas en kwyjibo por eso.
	printf("1. Número de su signo del zodiago (Aries es 1)\n2. Película favorita (A, C, D, T)\n3. Cantidad de maldades del último mes (0 a 99)\n4. Cantidad de mascotas (0 a 5)\n\n");

	inicializar_juego(&juego);

	decidir_cuantos_jugadores(&cant_jugadores);

	if(cant_jugadores == DOS_JUGADOR){
		while(sigue_juego(juego)){
			turno_2_jugadores(&juego);
		}
	}else{
		while(sigue_juego(juego)){
			turno_1_jugador(&juego);
		}	
	}

	if(juego.llegadas_rohan >= LLEGADAS_TOTALES){
		printf("Los guerreros de Rohan han ganado!\n");		
	}else{
		printf("Los guerreros de Isengard han ganado!\n");
	}

	return 0;
}