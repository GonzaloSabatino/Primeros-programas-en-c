#include <stdio.h>

#define MAX_TABLERO 10

typedef struct juego{
	char tablero[MAX_TABLERO][MAX_TABLERO];
}juego_t;

void asignar_barcos(juego_t* juego){
	juego->tablero[2][3] = 'B';
	juego->tablero[3][3] = 'B';
	juego->tablero[4][3] = 'B';
	juego->tablero[5][3] = 'B';
	juego->tablero[6][3] = 'B';
	juego->tablero[7][3] = 'B';
}

void imprimir_tablero(juego_t* juego, int fil, int col){
	
}

int main(){
	juego_t juego;
	int fil, col;
	int i = 0;

	asignar_barcos(&juego);

	do{
		printf("Fil y col: \n");
		scanf("%i %i", &fil, &col);
		imprimir_tablero(&juego, fil, col);
	}while(i < 5);

	return 0;
}