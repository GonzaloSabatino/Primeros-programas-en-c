#include <stdio.h>

#define MAX_TABLERO 10

typedef struct juego{
	char tablero[MAX_TABLERO][MAX_TABLERO];
}juego_t;

int main(){
	juego_t juego;
	int fil, col;

	juego.tablero[2][3] = 'X';

	for(int fil = 0; fil < MAX_TABLERO; fil++){
		for (int col = 0; col < MAX_TABLERO; col++){
			printf(" ");
		}
		printf("\n");
	}

	printf("Ingrese fil y col: \n");
	scanf("%i %i", &fil, &col);

	if(juego.tablero[fil][col] == 'X')
		printf("acerto\n");
	else
		printf("no acerto\n");


	return 0;
}