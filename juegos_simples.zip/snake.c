#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

#define MAX_POSICIONES 20

typedef struct personaje{
	bool se_comio;
	int cantidad_comidos;
	int fila_posiciones[MAX_POSICIONES];
	int columna_posiciones[MAX_POSICIONES];
}personaje_t;

typedef struct apple{
	int fila_apple;
	int columna_apple;
}apple_t;

typedef struct juego{
	char terreno[MAX_POSICIONES][MAX_POSICIONES];
	int cantidad_posiciones;
}juego_t;

typedef struct obstaculo{
	int fil_obstaculo[MAX_POSICIONES];
	int col_obstaculo[MAX_POSICIONES];
	int cant_obstaculos;
}obstaculo_t;

void chequear_obstaculo(obstaculo_t* obs, personaje_t* personaje, int i){
	while(personaje->fila_posiciones[0] == obs->fil_obstaculo[i] && personaje->columna_posiciones[0] == obs->col_obstaculo[i]){
		obs->fil_obstaculo[obs->cant_obstaculos] = rand()% 20;
		obs->col_obstaculo[obs->cant_obstaculos] = rand()% 20;
	}
}

bool choco_obstaculo(obstaculo_t* obs, personaje_t* personaje){
	int i = 0;
	bool choco = false;

	while(i < obs->cant_obstaculos && !choco){
		if(personaje->fila_posiciones[0] == obs->fil_obstaculo[i] && personaje->columna_posiciones[0] == obs->col_obstaculo[i])
			choco = true;

		i++;
	}

	return choco;
}

bool termino_juego(personaje_t* personaje, bool comio_apple, bool* game_over, obstaculo_t* obs){
	bool termino = false;
	int i = personaje->cantidad_comidos;
	while(i > 0 && !termino){
		if(personaje->fila_posiciones[i] == personaje->fila_posiciones[0] && personaje->columna_posiciones[i] == personaje->columna_posiciones[0] && !comio_apple){
			termino = true;
			*game_over = true;
		}

		i--;
	}

	if(personaje->cantidad_comidos == 10)
		termino = true;

	if(choco_obstaculo(obs, personaje)){
		termino = true;
		*game_over = true;
	}

	return termino;
}

void cargar_vector(personaje_t* personaje, juego_t* juego, apple_t apple){
	juego->terreno[apple.fila_apple][apple.columna_apple] = '*';

	for(int i = 0; i < personaje->cantidad_comidos + 1; i++){
		if(i == 0)
			juego->terreno[personaje->fila_posiciones[i]][personaje->columna_posiciones[i]] = 'D';
		else
			juego->terreno[personaje->fila_posiciones[i]][personaje->columna_posiciones[i]] = '>';
	}
}

void blanquear_terreno(juego_t* juego){
	for(int i = 0; i < MAX_POSICIONES; i++){
		for (int j = 0; j < MAX_POSICIONES; j++){
			juego->terreno[i][j] = ' ';
		}
	}
}

void renovar_obstaculo(obstaculo_t* obs, juego_t* juego, int i, personaje_t* personaje){
	if(i % 6 == 0){
		obs->cant_obstaculos++;
		obs->fil_obstaculo[obs->cant_obstaculos] = rand()% 20;
		obs->col_obstaculo[obs->cant_obstaculos] = rand()% 20;
		for(int i = 1; i < obs->cant_obstaculos; i++){	
			chequear_obstaculo(obs, personaje, i);
		}
	}

	for(int i = 0; i < obs->cant_obstaculos; i++){
		juego->terreno[obs->fil_obstaculo[i]][obs->col_obstaculo[i]] = 'X';
	}
}

void imprimir_juego(personaje_t* personaje, juego_t* juego, apple_t apple, obstaculo_t* obs, int i){
	blanquear_terreno(juego);
	cargar_vector(personaje, juego, apple);
	renovar_obstaculo(obs, juego, i, personaje);
	system("clear");
	printf("_____________________________________________________________________________\n");

	for(int i = 0; i < MAX_POSICIONES; i++){
		for(int j = 0; j < MAX_POSICIONES; j++){
			printf("%c|", juego->terreno[i][j]);
		}
		printf("\n");
	}

	printf("_____________________________________________________________________________\n");
}

void estado_inicial(personaje_t* personaje, juego_t* juego, apple_t* apple, obstaculo_t* obs){
	personaje->cantidad_comidos = 0;
	personaje->se_comio = false;
	personaje->fila_posiciones[personaje->cantidad_comidos] = rand()% 20;
	personaje->columna_posiciones[personaje->cantidad_comidos] = rand()% 20;
	apple->fila_apple = rand()% 20;
	apple->columna_apple = rand()% 20;
	obs->cant_obstaculos = 0;
	obs->fil_obstaculo[obs->cant_obstaculos] = rand()% 20;
	obs->col_obstaculo[obs->cant_obstaculos] = rand()% 20;
	chequear_obstaculo(obs, personaje, 0);
}

void ocupar_posicion_anterior(int fil[MAX_POSICIONES], int col[MAX_POSICIONES], int cantidad_comidos){
	for(int i = cantidad_comidos; i > 0; i--){
		fil[i] = fil[i-1];
		col[i] = col[i-1];
	}
}

void control_pared(personaje_t* personaje){
	if(personaje->fila_posiciones[0] < 0)
		personaje->fila_posiciones[0] = 19;
	else if(personaje->fila_posiciones[0] > 19)
		personaje->fila_posiciones[0] = 0;
	if(personaje->columna_posiciones[0] < 0)
		personaje->columna_posiciones[0] = 19;
	else if(personaje->columna_posiciones[0] > 19)
		personaje->columna_posiciones[0] = 0;
}

void mover_personaje(personaje_t* personaje){
	char movimiento;

	printf("para donde quiere mover:\n");
	scanf(" %c", &movimiento);

	ocupar_posicion_anterior(personaje->fila_posiciones, personaje->columna_posiciones, personaje->cantidad_comidos);
	if(movimiento == 'w')
		personaje->fila_posiciones[0]--;
	else if(movimiento == 's')
		personaje->fila_posiciones[0]++;
	else if(movimiento == 'a')
		personaje->columna_posiciones[0]--;
	else if(movimiento == 'd')
		personaje->columna_posiciones[0]++;
	else
		printf("%i, %i\n", personaje->fila_posiciones[0], personaje->columna_posiciones[0]);

	control_pared(personaje);
}

bool comio(personaje_t personaje, apple_t apple, bool* comio_apple){
	if (personaje.fila_posiciones[personaje.cantidad_comidos] == apple.fila_apple && personaje.columna_posiciones[personaje.cantidad_comidos] == apple.columna_apple){
		*comio_apple = true;
		return true;
	}else{
		*comio_apple = false;
		return false;
	}
}

void agregar_personaje(personaje_t* personaje){
	personaje->cantidad_comidos++;
	personaje->fila_posiciones[personaje->cantidad_comidos] = personaje->fila_posiciones[personaje->cantidad_comidos-1]; 
	personaje->columna_posiciones[personaje->cantidad_comidos] = personaje->columna_posiciones[personaje->cantidad_comidos-1]; 
}

void agregar_apple(apple_t* apple, personaje_t personaje){
	apple->fila_apple = rand()% 20;
	apple->columna_apple = rand()% 20;
}

int main(){
	srand(time(NULL));
	personaje_t personaje;
	juego_t juego;
	apple_t apple;
	bool comio_apple;
	bool game_over = false;
	obstaculo_t obs;
	int i = 0;

	estado_inicial(&personaje, &juego, &apple, &obs);
	imprimir_juego(&personaje, &juego, apple, &obs, i);

	do{
		mover_personaje(&personaje);
		imprimir_juego(&personaje, &juego, apple, &obs, i);
		if(comio(personaje, apple, &comio_apple)){
			agregar_apple(&apple, personaje);
			agregar_personaje(&personaje);
		}
		i++;
	}while(!termino_juego(&personaje, comio_apple, &game_over, &obs));

	if(game_over)
		printf("GAME OVER\n");
	else
		printf("GANADOR... COMISTE 10 MANZANAS\n");

	return 0;
}