#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_JUGADAS 9
#define MAX_TABLERO 3

const int JUGADAS_INICIALES = 0;
const int INICIO_TABLERO = 0;
const int INCREMENTO = 1;
const int DOBLE_INCREMENTO = 2;
const int JUGADAS_MAX = 5;

const char ICONO_JUG_UNO = 'X';
const char ICONO_JUG_DOS = 'O';
const char ESTADO_INICIAL = ' ';

typedef struct jugador{
	int fil_jugadas[MAX_JUGADAS];
	int col_jugadas[MAX_JUGADAS];
	int cant_jugadas;
	char icono;
}jugador_t;

typedef struct tablero{
	char terreno[MAX_TABLERO][MAX_TABLERO];
}tablero_t;

bool esta_horizontal(tablero_t tablero){
	bool esta = false;

	for(int fil = 0; fil < MAX_TABLERO; fil++){
		if(tablero.terreno[fil][INICIO_TABLERO] != ESTADO_INICIAL){
			if(tablero.terreno[fil][INICIO_TABLERO + INCREMENTO] == tablero.terreno[fil][INICIO_TABLERO] && tablero.terreno[fil][INICIO_TABLERO + DOBLE_INCREMENTO] == tablero.terreno[fil][INICIO_TABLERO])
				esta = true;
		}
	}

	return esta;
}

bool esta_vertical(tablero_t tablero){
	bool esta = false;

	for(int col = 0; col < MAX_TABLERO; col++){
		if(tablero.terreno[INICIO_TABLERO][col] != ESTADO_INICIAL){
			if(tablero.terreno[INICIO_TABLERO + INCREMENTO][col] == tablero.terreno[INICIO_TABLERO][col] && tablero.terreno[INICIO_TABLERO + DOBLE_INCREMENTO][col] == tablero.terreno[INICIO_TABLERO][col])
				esta = true;
		}
	}

	return esta;
}

bool esta_diagonal(tablero_t tablero){
	bool esta = false;

	if(tablero.terreno[INICIO_TABLERO][INICIO_TABLERO] != ESTADO_INICIAL){
		if(tablero.terreno[INICIO_TABLERO][INICIO_TABLERO] == tablero.terreno[INICIO_TABLERO + INCREMENTO][INICIO_TABLERO + INCREMENTO] && tablero.terreno[INICIO_TABLERO][INICIO_TABLERO] == tablero.terreno[INICIO_TABLERO + DOBLE_INCREMENTO][INICIO_TABLERO + DOBLE_INCREMENTO])
			esta = true;
	}else if(tablero.terreno[INICIO_TABLERO][INICIO_TABLERO + DOBLE_INCREMENTO] != ESTADO_INICIAL){
		if(tablero.terreno[INICIO_TABLERO][INICIO_TABLERO + DOBLE_INCREMENTO] == tablero.terreno[INICIO_TABLERO + INCREMENTO][INICIO_TABLERO + INCREMENTO] && tablero.terreno[INICIO_TABLERO][INICIO_TABLERO + DOBLE_INCREMENTO] == tablero.terreno[INICIO_TABLERO + DOBLE_INCREMENTO][INICIO_TABLERO])
			esta = true;
	}

	return esta;
}

bool termino(tablero_t tablero, jugador_t jug_uno, jugador_t jug_dos){
	bool en_raya = false;
	if(esta_horizontal(tablero))
		en_raya = true;
	else if(esta_vertical(tablero))
		en_raya = true;
	else if(esta_diagonal(tablero))
		en_raya = true;
	else if(jug_uno.cant_jugadas == JUGADAS_MAX || jug_dos.cant_jugadas == JUGADAS_MAX)
		en_raya = true;

	return en_raya;
}

void datos_iniciales(jugador_t* jugador, char icono_recibido){
	jugador->cant_jugadas = JUGADAS_INICIALES;
	jugador->icono = icono_recibido;
}

void validar_posicion(int* fil, int* col, tablero_t tablero){
	while(tablero.terreno[*fil][*col] != ESTADO_INICIAL){
		printf("Ingrese nuevamente fila de movimiento: \n");
		scanf("%i", fil);
		printf("Ingrese nuevamente columna de movimiento: \n");
		scanf("%i", col);
	}
}

void ingresar_posicion(jugador_t* jugador, tablero_t tablero){
	printf("Ingrese fila de movimiento: \n");
	scanf("%i", &(jugador->fil_jugadas[jugador->cant_jugadas]));
	printf("Ingrese columna de movimiento: \n");
	scanf("%i", &(jugador->col_jugadas[jugador->cant_jugadas]));

	validar_posicion(&(jugador->fil_jugadas[jugador->cant_jugadas]), &(jugador->col_jugadas[jugador->cant_jugadas]), tablero);

	jugador->cant_jugadas += INCREMENTO;
}

void inicializar_tablero(tablero_t* tablero){
	for(int fil = 0; fil < MAX_TABLERO; fil++){
		for(int col = 0; col < MAX_TABLERO; col++){
			tablero->terreno[fil][col] = ESTADO_INICIAL;
		}
	}
}

void colocar_en_tablero(jugador_t jugador, tablero_t* tablero){
	for(int i = 0; i < jugador.cant_jugadas; i++){
		tablero->terreno[jugador.fil_jugadas[i]][jugador.col_jugadas[i]] = jugador.icono;
	}
}

void imprimir_tablero(tablero_t tablero){
	printf("  __________ \n");
	for(int fil = 0; fil < MAX_TABLERO; fil++){
		printf("%i |", fil);
		for(int col = 0; col < MAX_TABLERO; col++){
			printf("%c |", tablero.terreno[fil][col]);
		}
		printf("\n");
		printf("  |__|__|__| \n");
	}
	printf("   0  1  2  \n");
}

int main(){
	jugador_t jug_uno;
	jugador_t jug_dos;
	tablero_t tablero;

	datos_iniciales(&jug_uno, ICONO_JUG_UNO);
	datos_iniciales(&jug_dos, ICONO_JUG_DOS);
	inicializar_tablero(&tablero);

	while(!termino(tablero, jug_uno, jug_dos)){
		system("clear");
		imprimir_tablero(tablero);
		ingresar_posicion(&jug_uno, tablero);
		colocar_en_tablero(jug_uno, &tablero);

		system("clear");
		imprimir_tablero(tablero);
		ingresar_posicion(&jug_dos, tablero);
		colocar_en_tablero(jug_dos, &tablero);
		
		imprimir_tablero(tablero);
	}

	return 0;
}
