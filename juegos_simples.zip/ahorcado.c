#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ACERTIJO 30
const int INICIO_INTENTOS = 0;
const int INICIO_TOPE = 0;
const int INICIO_INCREMENTO = 0;
const int INCREMENTO = 1;

void ingresar_letra(char* ingresada){
	printf("\nIngrese una letra: \n");
	scanf(" %c", ingresada);
}

void imprimir_intentos(int intentos, int fin){
	printf("\nCantidad de intentos: %i\n", fin - intentos);
}

void imprimir_palabra_cifrada(char acertijo[MAX_ACERTIJO], int tope, char adivinadas[MAX_ACERTIJO], int tope_adivinadas){
	bool letra_adivinada;

	for(int i = 0; i < tope; i++){
		letra_adivinada = false;
		for(int j = 0; j < tope_adivinadas; j++){
			if(acertijo[i] == adivinadas[j])
				letra_adivinada = true;
		}
		if(letra_adivinada)
			printf("%c ", acertijo[i]);
		else
			printf("_ ");
	}
}

bool letra_cumple(char acertijo[MAX_ACERTIJO], int tope, char ingresada){
	bool cumple = false;
	int i = 0;

	while(i < tope && !cumple){
		if(acertijo[i] == ingresada)
			cumple = true;
		i++;
	}

	return cumple;
}

void validar_intento_letra(char acertijo[MAX_ACERTIJO], int tope, char ingresada, char adivinadas[MAX_ACERTIJO], int* tope_adivinadas, int* intentos){
	if(letra_cumple(acertijo, tope, ingresada)){
		adivinadas[*tope_adivinadas] = ingresada;
		*tope_adivinadas+=INCREMENTO;
	}else{
		*intentos+=INCREMENTO;
	}
}

bool se_encuentra_letra(char acertijo[MAX_ACERTIJO], int pos, char adivinadas[MAX_ACERTIJO], int tope_adivinadas){
	bool encontrada = false;
	int j = INICIO_INCREMENTO;

	while(j < tope_adivinadas && !encontrada){
		if(acertijo[pos] == adivinadas[j])
			encontrada = true;
		j++;
	}

	return encontrada;
}

bool acerto_palabra(char acertijo[MAX_ACERTIJO], int tope, char adivinadas[MAX_ACERTIJO], int tope_adivinadas, bool* acerto){
	int i = INICIO_INCREMENTO;
	*acerto = true;

	while(i < tope && *acerto){
		if(!se_encuentra_letra(acertijo, i, adivinadas, tope_adivinadas))
			*acerto = false;
		i++;
	}

	return *acerto;
}

bool termino(int fin, int intentos, char acertijo[MAX_ACERTIJO], int tope, char adivinadas[MAX_ACERTIJO], int tope_adivinadas, bool* acerto){
	return (intentos == fin || acerto_palabra(acertijo, fin, adivinadas, tope_adivinadas, acerto));
}

int main(){
	char acertijo[MAX_ACERTIJO];
	int fin;
	int intentos = INICIO_INTENTOS;
	char ingresada;
	char adivinadas[MAX_ACERTIJO];
	int tope_adivinadas = INICIO_TOPE;
	bool acerto;

	printf("\nIngrese una palabra para que el otro usuario adivine: \n");
	scanf("%s", acertijo);
	fin = strlen(acertijo);
	system("clear");
	for(int i = 0; i < fin; i++){
		printf("_ ");
	}

	do{
		imprimir_intentos(intentos, fin);
		ingresar_letra(&ingresada);
		validar_intento_letra(acertijo, fin, ingresada, adivinadas, &tope_adivinadas, &intentos);
		imprimir_palabra_cifrada(acertijo, fin, adivinadas, tope_adivinadas);
		system("clear");
	}while(!termino(fin, intentos, acertijo, fin, adivinadas, tope_adivinadas, &acerto));

	if(acerto)
		printf("\nGANADOR\n");
	else
		printf("\nPERDEDOR\n");

	return 0;
}