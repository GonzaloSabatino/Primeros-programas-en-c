#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include "censo.h"

const int SON_IGUALES = 0;
const int POSICION_FUNCION = 1;
const int POSICION_ESPERADA_ACTUALIZAR = 2;
const int TOPE_ACTUALIZAR = 3;
const int POSICION_ESPERADA_INTEGRANTES = 5;
const int TOPE_INTEGRANTES = 6;
const int MISION_SE_CHEQUEO = 1;
const int POSICION_RANGOS = 2;
const int POSICION_GUERREROS = 2;
const int POSICION_LIDERES = 3;
const int POSICION_GENERALES = 4;



int main(int argc, char const *argv[]){
	char nombre_mision[MAX_NOMBRE];
	if(strcmp(argv[POSICION_FUNCION], "listar_enanos") == SON_IGUALES){
		listar_enanos(atoi(argv[POSICION_RANGOS]));
	}else if(strcmp(argv[POSICION_FUNCION], "actualizar_censo") == SON_IGUALES){
		poner_nombre_mision(argc, argv, nombre_mision, POSICION_ESPERADA_ACTUALIZAR, TOPE_ACTUALIZAR);
		actualizar_censo(nombre_mision);
	}else if(strcmp(argv[POSICION_FUNCION], "integrantes_mision") == SON_IGUALES){
		poner_nombre_mision(argc, argv, nombre_mision, POSICION_ESPERADA_INTEGRANTES, TOPE_INTEGRANTES);
		if(mision_chequeada(nombre_mision) == MISION_SE_CHEQUEO){
			elegir_enanos(atoi(argv[POSICION_GUERREROS]), atoi(argv[POSICION_LIDERES]), atoi(argv[POSICION_GENERALES]), nombre_mision);
		}
	}else if(strcmp(argv[POSICION_FUNCION], "promover_enanos") == SON_IGUALES){
		promover_enanos();
	}else{
		ayudar_usuario();
	}

	return 0;
}