#ifndef __CENSO_H__
#define __CENSO_H__

#define MAX_NOMBRE 50
#define MAX_RANGO 50
#define MAX_DESCRIPCION 200

typedef struct enano{
char nombre[MAX_NOMBRE];
int edad;
int cantidad_misiones;
int id_rango;
}enano_t;

typedef struct rango{
int id;
char nombre[MAX_RANGO];
char descripcion[MAX_DESCRIPCION];
}rango_t;

/*
 *	Pre-condiciones: El rango ingresado debe ser un número entero y positivo.
 *	Post-condiciones: Mostrará por pantalla el rango solicitado, su descripción y qué enanos cumplen con ella.
 */
int listar_enanos(int rango_solicitado);

/*
 *	Pre-condiciones: Los parámetros enteros, deben ser números positivos.
 *	Post-condiciones: Concatenará "mision" con lo ingresado por el usuario en la última posición (si es que lo ingresó) y un ".dat".
 */
void poner_nombre_mision(int argc, char const *argv[], char nombre_mision[MAX_NOMBRE], int posicion_nombre, int tope_requerido);

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir y la vida de los nuevos enanos debe ser mayor que 0, así como el resto de los campos de todos los enanos.
 *	Post-condiciones: Eliminará ordenadamente los enanos que tengan un -1 en la edad, agregará ordenadamente los enanos nuevos que aparecen en "mision__.dat" y sumará uno a la cantidad de misiones de los enanos que si se encuentren en ambos archivos
 */
int actualizar_censo(char nombre_mision[MAX_NOMBRE]);

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir y tres parámetros deben ser números enteros y positivos.
 *	Post-condiciones: Asignará al archivo de la misión la cantidad de enanos de cada rango, si los hay, que solicitó el usuario. Si no hay esa cantidad, se eliminará el archivo. Además, asignará hasta 10 aprendices.
 */
int elegir_enanos(int cantidad_guerreros, int cantidad_lideres, int cantidad_generales, char nombre_mision[MAX_NOMBRE]);

/*
 *	Pre-condiciones: El arhivo "censo.csv" debe existir.
 *	Post-condiciones: Sumará uno al rango de los enanos que se encuentren en condiciones de ascender.
 */
int promover_enanos();

/*
 *	Pre-condiciones: El nombre debe estar ingresado correctamente.
 *	Post-condiciones: Devolverá 1 en caso de que la misión solicitada no exista, 2 en caso de que si exista.
 */
int mision_chequeada(char nombre_mision[MAX_NOMBRE]);

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Mostrará por pantalla los comandos disponibles para ser usador por terminal
 */
void ayudar_usuario();

#endif /* __CENSO_H__ */