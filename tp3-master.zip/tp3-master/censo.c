#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include "censo.h"

const int SALIO_BIEN = 0;
const int ERROR_CENSO = 1;
const int ERROR_ACTUALIZACION = 2;
const int ERROR_MISION = 3;
const int NO_EXISTE_ARCHIVO = 1;
const int EXISTE_ARCHIVO = 2;

const char* LISTAR_ENANOS = {"listar_enanos"};
const char* PROMOVER_ENANOS = {"promover_enanos"};
const char* ACTUALIZAR_CENSO = {"actualizar_censo"};
const char* INTEGRANTES_MISION = {"integrantes_mision"};

const int VIDA_PERDIDO = -1;
const int SUMAR_CANT_MISIONES = 1;

const int OBRERO = 1;
const int APRENDIZ = 2;
const int GUERRERO = 3;
const int LIDER = 4;
const int GENERAL = 5;

const int TOPE_APRENDIZ = 10;

const int CONTADOS_INICIALES = 0;

const int EDAD_MINIMA_APRENDIZ = 0;
const int EDAD_MAXIMA_APRENDIZ = 100000;
const int MISIONES_MINIMAS_APRENDIZ = 10;
const int EDAD_MINIMA_GUERRERO = 40;
const int EDAD_MAXIMA_GUERRERO = 50;
const int MISIONES_MINIMAS_GUERRERO = 100;
const int EDAD_MINIMA_LIDER = 50;
const int EDAD_MAXIMA_LIDER = 60;
const int MISIONES_MINIMAS_LIDER = 250;

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir.
 *	Post-condiciones: Verificará que el nombre del enano se encuentre en la misión, retornando true en ese caso, false en caso de que no se encuentre.
 */
bool esta_en_censo(char nombre[MAX_NOMBRE]){
	int leidos;
	enano_t enano;
	bool enano_en_censo = false;
	FILE* censo = fopen("censo.csv", "rb+");
	if(!censo){
		perror("ERROR CENSO");
		return false;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano.nombre), &(enano.edad), &(enano.cantidad_misiones), &(enano.id_rango));
	while(leidos != EOF && !enano_en_censo){
		if(strcmp(nombre, enano.nombre) == 0)
			enano_en_censo = true;
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano.nombre), &(enano.edad), &(enano.cantidad_misiones), &(enano.id_rango));
	}

	fclose(censo);

	return enano_en_censo;
}

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir.
 *	Post-condiciones: Sumará uno a la cantidad de misiones del enano que tenga el nombre recibido.
 */
int sumar_cantidad_misiones(char nombre[MAX_NOMBRE]){
	int leidos;
	enano_t enano;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return ERROR_CENSO;
	}

	FILE* censo_actualizado = fopen("censo_actualizado.csv", "w");
	if(!censo_actualizado){
		perror("ERROR CENSO ACTUALIZADO");
		fclose(censo);
		return ERROR_ACTUALIZACION;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano.nombre), &(enano.edad), &(enano.cantidad_misiones), &(enano.id_rango));
	while(leidos != EOF){
		if(strcmp(nombre, enano.nombre) == 0){
			enano.cantidad_misiones += SUMAR_CANT_MISIONES;
		}
		fprintf(censo_actualizado, "%s;%i;%i;%i\n", (enano.nombre), (enano.edad), (enano.cantidad_misiones), (enano.id_rango));
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano.nombre), &(enano.edad), &(enano.cantidad_misiones), &(enano.id_rango));
	}

	fclose(censo);
	fclose(censo_actualizado);

	remove("censo.csv");
	rename("censo_actualizado.csv", "censo.csv");

	return SALIO_BIEN;
}

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir.
 *	Post-condiciones: Eliminará del censo al enano que posea el nombre recibido.
 */
int eliminar_del_censo(char nombre[MAX_NOMBRE]){
	int leidos;
	enano_t enano;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return ERROR_CENSO;
	}

	FILE* censo_actualizado = fopen("censo_actualizado.csv", "w");
	if(!censo_actualizado){
		perror("ERROR CENSO ACTUALIZADO");
		fclose(censo);
		return ERROR_ACTUALIZACION;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano.nombre), &(enano.edad), &(enano.cantidad_misiones), &(enano.id_rango));
	while(leidos != EOF){
		if(strcmp(nombre, enano.nombre) != 0)
			fprintf(censo_actualizado, "%s;%i;%i;%i\n", (enano.nombre), (enano.edad), (enano.cantidad_misiones), (enano.id_rango));
		
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano.nombre), &(enano.edad), &(enano.cantidad_misiones), &(enano.id_rango));
	}

	fclose(censo);
	fclose(censo_actualizado);

	remove("censo.csv");
	rename("censo_actualizado.csv", "censo.csv");

	return SALIO_BIEN;
}

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir y el enano debe estar cargado correctamente.
 *	Post-condiciones: Insertará al censo el enano nuevo, recibido como parámetro.
 */
int insertar_enano_perdido(enano_t enano){
	int leidos;
	enano_t enano_censo;
	bool es_menor = false;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return ERROR_CENSO;
	}

	FILE* censo_actualizado = fopen("censo_actualizado.csv", "w");
	if(!censo_actualizado){
		perror("ERROR CENSO ACTUALIZADO");
		fclose(censo);
		return ERROR_ACTUALIZACION;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	while(leidos != EOF && !es_menor){
		if(strcmp(enano.nombre, enano_censo.nombre) < 0){
			fprintf(censo_actualizado, "%s;%i;%i;%i\n", (enano.nombre), (enano.edad), (enano.cantidad_misiones), (enano.id_rango));
			es_menor = true;
		}

		fprintf(censo_actualizado, "%s;%i;%i;%i\n", (enano_censo.nombre), (enano_censo.edad), (enano_censo.cantidad_misiones), (enano_censo.id_rango));
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	}

	while(leidos != EOF){
		fprintf(censo_actualizado, "%s;%i;%i;%i\n", (enano_censo.nombre), (enano_censo.edad), (enano_censo.cantidad_misiones), (enano_censo.id_rango));
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	
	}

	if(!es_menor){
		fprintf(censo_actualizado, "%s;%i;%i;%i\n", (enano.nombre), (enano.edad), (enano.cantidad_misiones), (enano.id_rango));
	}

	fclose(censo);
	fclose(censo_actualizado);

	remove("censo.csv");
	rename("censo_actualizado.csv", "censo.csv");

	return SALIO_BIEN;
}

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir y la vida de los nuevos enanos debe ser mayor que 0, así como el resto de los campos de todos los enanos.
 *	Post-condiciones: Eliminará ordenadamente los enanos que tengan un -1 en la edad, agregará ordenadamente los enanos nuevos que aparecen en "mision__.dat" y sumará uno a la cantidad de misiones de los enanos que si se encuentren en ambos archivos
 */
int actualizar_censo(char nombre_mision[MAX_NOMBRE]){
	enano_t enano;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return ERROR_CENSO;
	}

	FILE* mision = fopen(nombre_mision, "r");
	if(!mision){
		perror("ERROR MISION");
		fclose(censo);
		return ERROR_MISION;
	}

	fread(&enano, sizeof(enano_t), 1, mision);
	while(!feof(mision)){
		if(esta_en_censo(enano.nombre)){
			if(enano.edad > VIDA_PERDIDO){
				sumar_cantidad_misiones(enano.nombre);
			}else{
				eliminar_del_censo(enano.nombre);
			}
		}else{
			insertar_enano_perdido(enano);
		}

		fread(&enano, sizeof(enano_t), 1, mision);
	}
	
	fclose(censo);
	fclose(mision);

	return SALIO_BIEN;
}

/*
 *	Pre-condiciones: Ambos parámetros recibidos deben ser numeros enteros y positivos.
 *	Post-condiciones: Verificará que del rango solicitado, hay la cantidad de enanos pedidos por el usuario.
 */
bool hay_cantidad_enanos_pedidos(int rango_solicitado, int cantidad_solicitada){
	int leidos;
	enano_t enano_censo;
	int i = CONTADOS_INICIALES;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return false;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	while(leidos != EOF && i < cantidad_solicitada){
		if(enano_censo.id_rango == rango_solicitado){
			i++;
		}
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	}

	fclose(censo);

	if(i == cantidad_solicitada)
		return true;
	else
		return false;
}

/*
 *	Pre-condiciones: Todos los parámetros recibidos deben ser números enteros positivos y el archivo "censo.csv" debe existir.
 *	Post-condiciones: Asignará al archivo "mision__.dat" la cantidad de enanos solicitados por el usuario de cada rango y hasta 10 aprendices
 */
int sumar_a_mision(int tope_guerreros, int tope_lideres, int tope_generales, int tope_aprendices, char nombre_mision[MAX_NOMBRE]){
	int leidos;
	enano_t enano;
	int i = CONTADOS_INICIALES;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return ERROR_CENSO;
	}

	FILE* mision = fopen(nombre_mision, "w");
	if(!mision){
		perror("ERROR CENSO");
		fclose(censo);
		return ERROR_MISION;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano.nombre), &(enano.edad), &(enano.cantidad_misiones), &(enano.id_rango));
	while(leidos != EOF){
		if(enano.id_rango == GUERRERO && tope_guerreros > CONTADOS_INICIALES){
			tope_guerreros--;
			fwrite(&enano, sizeof(enano_t), 1, mision);
		}else if(enano.id_rango == LIDER && tope_lideres > CONTADOS_INICIALES){
			tope_lideres--;
			fwrite(&enano, sizeof(enano_t), 1, mision);
		}else if(enano.id_rango == GENERAL && tope_generales > CONTADOS_INICIALES){
			tope_generales--;
			fwrite(&enano, sizeof(enano_t), 1, mision);
		}else if(enano.id_rango == APRENDIZ && i < tope_aprendices){
			i++;
			fwrite(&enano, sizeof(enano_t), 1, mision);
		}
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano.nombre), &(enano.edad), &(enano.cantidad_misiones), &(enano.id_rango));
	}

	fclose(censo);	
	fclose(mision);

	return SALIO_BIEN;	
}

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir.
 *	Post-condiciones: Contará cuántos aprendices hay en todo el censo.
 */
int cantidad_aprendices_censo(){
	int i = CONTADOS_INICIALES;
	int leidos;
	enano_t enano_censo;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return false;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	while(leidos != EOF && i < TOPE_APRENDIZ){
		if(enano_censo.id_rango == APRENDIZ){
			i++;
		}
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	}

	fclose(censo);

	return i;
}

/*
 *	Pre-condiciones: El archivo "censo.csv" debe existir y tres parámetros deben ser números enteros y positivos.
 *	Post-condiciones: Asignará al archivo de la misión la cantidad de enanos de cada rango, si los hay, que solicitó el usuario. Si no hay esa cantidad, se eliminará el archivo. Además, asignará hasta 10 aprendices.
 */
int elegir_enanos(int cantidad_guerreros, int cantidad_lideres, int cantidad_generales, char nombre_mision[MAX_NOMBRE]){
	int cantidad_aprendices = cantidad_aprendices_censo();
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return ERROR_CENSO;
	}

	FILE* mision = fopen(nombre_mision, "w");
	if(!mision){
		perror("ERROR CENSO");
		fclose(censo);
		return ERROR_MISION;
	}

	if(hay_cantidad_enanos_pedidos(GUERRERO, cantidad_guerreros) && hay_cantidad_enanos_pedidos(LIDER, cantidad_lideres) && hay_cantidad_enanos_pedidos(GENERAL, cantidad_generales)){
		sumar_a_mision(cantidad_guerreros, cantidad_lideres, cantidad_generales, cantidad_aprendices, nombre_mision);
		fclose(mision);
	}else{
		fclose(mision);
		remove(nombre_mision);
	}

	fclose(censo);

	return SALIO_BIEN;
}

/*
 *	Pre-condiciones: El enano recibido debe estar correctamente cargado y el resto de los parámetros deben ser números enteros y positivos.
 *	Post-condiciones: Retornará true en caso de que el enano cumpla las condiciones pedidas en el enunciado para ascender, false en caso de que no.
 */
bool puede_ascender(enano_t enano, int edad_minima_rango, int edad_maxima_rango, int misiones_minimas_rango){
	return ((enano.cantidad_misiones > misiones_minimas_rango) && (enano.edad <= edad_maxima_rango && enano.edad >= edad_minima_rango));
}

/*
 *	Pre-condiciones: El arhivo "censo.csv" debe existir.
 *	Post-condiciones: Sumará uno al rango de los enanos que se encuentren en condiciones de ascender.
 */
int promover_enanos(){
	int leidos;
	enano_t enano_censo;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return ERROR_CENSO;
	}

	FILE* censo_actualizado = fopen("censo_actualizado.csv", "w");
	if(!censo_actualizado){
		perror("ERROR CENSO ACTUALIZADO");
		fclose(censo);
		return ERROR_ACTUALIZACION;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	while(leidos != EOF){
		if(enano_censo.id_rango == APRENDIZ){
			if(puede_ascender(enano_censo, EDAD_MINIMA_APRENDIZ, EDAD_MAXIMA_APRENDIZ, MISIONES_MINIMAS_APRENDIZ)){
				enano_censo.id_rango = GUERRERO;
			}
		}else if(enano_censo.id_rango == GUERRERO){
			if(puede_ascender(enano_censo, EDAD_MINIMA_GUERRERO, EDAD_MAXIMA_GUERRERO, MISIONES_MINIMAS_GUERRERO)){
				enano_censo.id_rango = LIDER;
			}
		}else if(enano_censo.id_rango == LIDER){
			if(puede_ascender(enano_censo, EDAD_MINIMA_LIDER, EDAD_MAXIMA_LIDER, MISIONES_MINIMAS_LIDER)){
				enano_censo.id_rango = GENERAL;
			}
		}
		fprintf(censo_actualizado, "%s;%i;%i;%i\n", (enano_censo.nombre), (enano_censo.edad), (enano_censo.cantidad_misiones), (enano_censo.id_rango));	
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	}

	fclose(censo);
	fclose(censo_actualizado);

	remove("censo.csv");
	rename("censo_actualizado.csv", "censo.csv");

	return SALIO_BIEN;
}

/*
 *	Pre-condiciones: El archivo "rangos.dat" debe existir.
 *	Post-condiciones: Describirá todo lo que tiene el rango solicitado en el archivo de "rangos.dat".
 */
int escribir_descripcion(int rango_solicitado){
	rango_t rango;
	FILE* rangos = fopen("rangos.dat", "r");
	if(!rangos){
		perror("ERROR RANGOS");
		return 1;
	}

	fseek(rangos, (long)(rango_solicitado - 1)*(long)(sizeof(rango_t)), SEEK_SET);
	fread(&rango, sizeof(rango_t), 1, rangos);
	printf("%s:\n%s\n", rango.nombre, rango.descripcion);

	fclose(rangos);

	return 0;
}

/*
 *	Pre-condiciones: El rango ingresado debe ser un número entero y positivo.
 *	Post-condiciones: Mostrará por pantalla el rango solicitado, su descripción y qué enanos cumplen con ella.
 */
int listar_enanos(int rango_solicitado){
	int leidos;
	enano_t enano_censo;
	FILE* censo = fopen("censo.csv", "r");
	if(!censo){
		perror("ERROR CENSO");
		return ERROR_CENSO;
	}

	leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	escribir_descripcion(rango_solicitado);
	while(leidos != EOF){
		if(enano_censo.id_rango == rango_solicitado){
			printf("%s;%i;%i;%i\n", (enano_censo.nombre), (enano_censo.edad), (enano_censo.cantidad_misiones), (enano_censo.id_rango));
		}
		leidos = fscanf(censo, "%[^;];%i;%i;%i\n", (enano_censo.nombre), &(enano_censo.edad), &(enano_censo.cantidad_misiones), &(enano_censo.id_rango));
	}

	fclose(censo);

	return SALIO_BIEN;
}

/*
 *	Pre-condiciones: Los parámetros enteros, deben ser números positivos.
 *	Post-condiciones: Concatenará "mision" con lo ingresado por el usuario en la última posición (si es que lo ingresó) y un ".dat".
 */
void poner_nombre_mision(int argc, char const *argv[], char nombre_mision[MAX_NOMBRE], int posicion_nombre, int tope_requerido){
	//strcpy(nombre_mision, "mision");
	if(argc == tope_requerido){
		strcpy(nombre_mision, argv[posicion_nombre]);
	}

	strcat(nombre_mision, ".dat");
}

/*
 *	Pre-condiciones: El nombre debe estar ingresado correctamente.
 *	Post-condiciones: Devolverá 1 en caso de que la misión solicitada no exista, 2 en caso de que si exista.
 */
int mision_chequeada(char nombre_mision[MAX_NOMBRE]){
	FILE* archivo_comprobado = fopen(nombre_mision, "r");

	if(!archivo_comprobado)
		return NO_EXISTE_ARCHIVO;
	else{
		fclose(archivo_comprobado);
		return EXISTE_ARCHIVO;
	}
}

/*
 *	Pre-condiciones: No tiene.
 *	Post-condiciones: Mostrará por pantalla los comandos disponibles para ser usador por terminal
 */
void ayudar_usuario(){
	printf("Usted puede elegir los siguientes comandos:\n");
	printf("ingresar_integrantes numero_guerreros numero_lideres numero_generales nombre_mision\n");
	printf("promover_enanos\n");
	printf("actualizar_censo nombre_mision\n");
	printf("listar_enanos numero_rango\n");
}